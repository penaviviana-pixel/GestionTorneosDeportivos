#pragma once
#include "TablaPosiciones.h"
